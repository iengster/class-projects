const express = require('express');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

// Health check endpoint
app.get('/', (req, res) => {
  res.json({
    status: 'ok',
    service: 'DevBank Backend API',
    version: '1.0.0',
    timestamp: new Date().toISOString()
  });
});

// Sample banking endpoint
app.get('/api/accounts', (req, res) => {
  res.json({
    accounts: [
      { id: 1, type: 'Checking', balance: 4250.00 },
      { id: 2, type: 'Savings',  balance: 12800.50 }
    ]
  });
});

app.listen(PORT, () => {
  console.log(`DevBank backend running on port ${PORT}`);
});
